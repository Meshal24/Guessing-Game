// CS145 Hybrid
// Programmers: 
// 11/04/2022
// Lab 1 - Guessing Game
// This program will allow you to play a guessing game!

package com.mycompany.mavenproject1;


import java.util.*;

public class GuessingGame {
    
  public static final int MAX = 100;
 
   public static void main(String args[]) {

    Scanner console = new Scanner(System.in);
        //Creates Scanner object
            introduction();
    gameProcesser(console);
 }
   
 public static void introduction() {
     //Displays the rules of the game
    System.out.println("This program allows you to play a guessing game.");
     System.out.println("I will think of a number between 1 and ");
     System.out.println(MAX + " and will allow you to guess until");
     System.out.println("you get it. For each guess, I will tell you");
     System.out.println("if the right answer is higher or lower");
    System.out.println("than your guess.");
    System.out.println();

 }//End of method intro
 
 public static int playGame(Scanner console) { //receives the Scanner console so user can input
    //runs one game
    Random r = new Random();
    //Creates Random object
    int solution = r.nextInt(MAX) + 1;
    //Creates random number to be used as solution
    System.out.println("I'm thinking of a number between 1 and " + MAX);
    System.out.print("Your guess? ");
    int guess = console.nextInt();
    //receives user's input as guess
    int guesses = 1;
    //initializes the total guesses the user takes to get the correct answer
    if (guess == solution) {
    System.out.println();
    System.out.println("You got it right in ONE guess!");
    System.out.println();
    } else {
    //if statement checks if user got it right on first try
    while (guess != solution) {
    guesses++;
    //tallies the user's guess
    if (guess > solution) {
    System.out.println();
    System.out.println("It's lower.");
    System.out.print("Your guess? ");
    guess = console.nextInt();
    //if guess is greater than solution, takes in new guess
    } else if (guess < solution) {
    System.out.println();
    System.out.println("It's higher");
    System.out.print("Your guess? ");
    guess = console.nextInt();
    //if guess is lower than solution, takes in new guess
 }//End of if else

  }//End of while
    System.out.println();
    System.out.println("You got it right in " + guesses + " guesses");
    System.out.println();
 }
    return guesses;
    //returns number of guesses in the game
  }//End of methode
 
 public static String playAgain(Scanner console) { //receives the Scanner console so user can input
    //asks the user if they would like to play again.
    System.out.print("Would you like to play again? ");
    String answer = console.next();
    //receives user's response
    while ((!answer.equals("yes")) && (!answer.equals("no"))) {
    System.out.println("Please type \"yes\" or \"no\"");
    answer = console.next();
    //changes answer variable to user's new response
 }
    
    //checks if user inputted a valid response
    if (answer.equals("yes")) {
    System.out.println();
    return "yes";
    } else {
     System.out.println();
    return "no";
 }
    
     //returns user's answer
  }//End pf methode
 
    public static void gameProcesser(Scanner console) {
    //runs the playGame method and interprets the playAgain method and runs either
    //the playGame method again, or runs the stats method if the user types "no."
    int bestGame = 9999;
    //counts the best game the user played
    int totalGuesses = playGame(console);
    //counts the total number of guesses taken
    if (totalGuesses < bestGame) {
    bestGame = totalGuesses;
 }
    
    int totalGames = 1;
    //counts total number of games played
    String response = playAgain(console);
    //assesses user's response whether they want to play again or not
    //inteprets first letter of user's response
     while (response.equals("yes")) {
    int guesses = playGame(console);
    totalGames++;
    if (guesses < bestGame) {
    bestGame = guesses;
 }
    
    //judges whether current score is best score
    totalGuesses += guesses;
    //cumulative sum adding guesses taken in current game to total guesses
    response = playAgain(console);

 }

    System.out.println("Overall results:");
    System.out.println("Total Games: " + totalGames);
    System.out.println("Total Guesses: " + totalGuesses);
    System.out.println("Guesses/Game: " + (double) totalGuesses / totalGames);
    System.out.println("Best Game: " + bestGame);
     //displays user stats

 }//Endo of method
}//End of class 

